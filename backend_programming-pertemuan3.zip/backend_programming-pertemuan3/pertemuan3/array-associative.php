<?php

# membuat array associative
$user = [
  'nama' => 'Aufa Billah',
  'jurusan' => 'Teknik Informatika',
  'alamat' => 'Depok'
];

# mengakses array associative
echo $user['nama'];
echo "<br>";
echo $user['alamat'];
