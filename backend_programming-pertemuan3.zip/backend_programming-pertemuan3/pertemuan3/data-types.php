<?php

# string
$nama = "Aufa Billah";

# integer
$umur = 30;

# float
$ipk = 3.90;

# boolean
$isMarried = false;
