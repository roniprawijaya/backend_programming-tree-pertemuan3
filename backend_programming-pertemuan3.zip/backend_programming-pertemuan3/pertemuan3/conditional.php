<?php

$nilai = 85;

# kondisi if
if ($nilai > 90) {
  echo "Nilai anda A";
}
# kondisi else if
else if ($nilai > 80) {
  echo "Nilai anda B";
}
# kondisi else
else {
  echo "Nilai anda C";
}
