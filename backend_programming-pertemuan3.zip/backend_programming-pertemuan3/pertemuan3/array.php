<?php

# membuat array
$animals = ['cat', 'dog', 'fish'];

# mengakses elemen array
echo "$animals[0] <br>";
echo "$animals[1] <br>";
