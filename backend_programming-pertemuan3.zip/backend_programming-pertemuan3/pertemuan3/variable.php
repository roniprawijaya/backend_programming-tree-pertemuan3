<?php

# membuat variable
$nama = "Aufa Billah";
$jurusan = "Teknik Informatika";

# mengakses variable
echo $nama;
echo $jurusan;
